def handler(event, context):
    # You need to invoke this function to win!
    return "You win!"